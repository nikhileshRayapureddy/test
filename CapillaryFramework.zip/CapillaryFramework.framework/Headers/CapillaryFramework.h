//
//  CapillaryFramework.h
//  CapillaryFramework
//
//  Created by Nikhilesh on 05/05/17.
//  Copyright © 2017 Capillary Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
@class BusinessLayer;
@class BaseBL;
@class AuthSignature;
//! Project version number for CapillaryFramework.
FOUNDATION_EXPORT double CapillaryFrameworkVersionNumber;

//! Project version string for CapillaryFramework.
FOUNDATION_EXPORT const unsigned char CapillaryFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CapillaryFramework/PublicHeader.h>


